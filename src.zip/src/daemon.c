// child process is adopted by init process, when parent process dies.
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <syslog.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/time.h>
#include "moveReports.h"
#include "backupDashboard.h"
#include "recordChanges.h"
#include "permissionChange.h"
#include "uploadFilecheck.h"

// signal handler, performs report transfer and backup
void sig_handler(int sigNum) {
   if (sigNum == SIGINT) {
      openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
      syslog(LOG_INFO, "SIGINT Interrupt Received, beginning immediate transfer and backup");
      closelog();
      // transfer reports from uploads to dashboard 
      if (moveReports() != 0) {
         // log error 
	 openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
	 syslog(LOG_ERR, "Failed transfer reports from uploads to dashboard, backup will not run on dashboard");
	 closelog();
         } else { // transfer reports success
            // log success transfer reports
            openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
            syslog(LOG_INFO, "Successful transfer reports from uploads to dashboard");
            closelog();
            
            // sleep for 5 seconds after transfer
            sleep(5);
            if (backupDashboard() != 0) {
	       // log error
	       openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
	       syslog(LOG_ERR, "Failed backup dashboard content");
	       closelog();
	    } else {
	       // log success backup dashboard
	       openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
	       syslog(LOG_INFO, "Successful backup dashboard content");
	       closelog();
	    }
	}
   }
}
 
int main()
{
    struct timeval tv;
    struct timezone tz;
    struct tm *today;
    
    int time1hr = 23;
    int time1min = 30;
    int time1sec = 0;
    
    int time2hr = 1;
    int time2min = 0;
    int time2sec = 0;
    
    // Implementation for Singleton Pattern if desired (Only one instance running)

    // create a child process      
    int pid = fork();
    
    if (pid > 0) {
       // if PID > 0 :: this is the parent
       
       // put watch on uploads folder when startup
       char path[100] = "/home/aaron/Documents/Assignment/uploads/";
       char *argv[] = { "sudo", "auditctl", "-w", path, "-p", "wrxa", NULL };
       execvp(argv[0], &argv[0]);
    
       exit(EXIT_SUCCESS);
    } else if (pid == 0) {
       // create the orphan process
       // elevate the orphan process to session leader, to lose controlling TTY
       // runs the process in a new session
       if (setsid() < 0) { exit(EXIT_FAILURE); }

       // fork here again , just to guarantee that the process is not a session leader
       int pid = fork();
       if (pid > 0) {
          // store pid in a file so other processes can easily find
          // for further implementations
          FILE *file = fopen("/home/aaron/Documents/Assignment/src/pid.txt", "w");
          fprintf(file, "%d", pid);
          fclose(file);
          exit(EXIT_SUCCESS);
       } else {
          // call umask() to set the file mode creation mask to 0
          umask(0);

          // change the current working dir to root.
          // this will eliminate any issues of running on a mounted drive, 
          // that potentially could be removed etc..
          if (chdir("/") < 0 ) { exit(EXIT_FAILURE); }

          // close all open file descriptors
          int x;
          for (x = sysconf(_SC_OPEN_MAX); x>=0; x--)
          {
             close (x);
          } 
          
          // signal handler, signal interrupt
          if (signal(SIGINT, sig_handler) == SIG_ERR) {
             openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             syslog(LOG_ERR, "SIGINT Error");
             closelog();
          }
          
          // keep process running with infinite loop
          while(1) {
             sleep(1);
             gettimeofday(&tv,&tz);
             today = localtime(&tv.tv_sec);
             
             // 11:30pm
             if (today->tm_hour == time1hr && today->tm_min == time1min && today->tm_sec == time1sec) {
    	        // check files in uploads folder
                uploadFilecheck();  
    	     }
             
             // countdown reaches the time set to perform operations
             if (today->tm_hour == time2hr && today->tm_min == time2min && today->tm_sec == time2sec) {
             	// change permission for uploads and dashboard
             	// lock folder and disable write access for group
             	// except owner
             	if (permissionChange(700) != 0) {
             	   // log error
             	   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_ERR, "Failed 700 permission change for uploads and dashboard");
             	   closelog();
             	} else {
             	   // log success permission changed
             	   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_INFO, "Successful 700 permission change for uploads and dashboard");
             	   closelog();
             	}
             	
             	// sleep 5 seconds after permission change
             	sleep(5);
             	
             	// document all changes made to uploads folder
                if (recordChanges() != 0) {
		   // log error 
		   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_ERR, "Failed documented changes to uploads folder");
             	   closelog();
             	} else {
             	   // log success record changes
             	   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_INFO, "Successful documented changes to uploads folder");
             	   closelog();
             	}
             	
             	// transfer reports from uploads to dashboard 
             	if (moveReports() != 0) {
		   // log error 
		   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_ERR, "Failed transfer reports from uploads to dashboard, backup will not run on dashboard");
             	   closelog();
             	} else { // transfer reports success
                   // log success transfer reports
             	   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_INFO, "Successful transfer reports from uploads to dashboard");
             	   closelog();
             	   
             	   // sleep for 5 seconds after transfer
		   sleep(5);
		   
		   if (backupDashboard() != 0) {
		      // log error
		      openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	      syslog(LOG_ERR, "Failed backup dashboard content");
             	      closelog();
		   } else {
		      // log success backup dashboard
		      openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	      syslog(LOG_INFO, "Successful backup dashboard content");
             	      closelog();
		   }
		}
		
		// sleep 5 seconds before permission change
		sleep(5);
		
		// change permission for uploads and dashboard
             	// unlock folder and enable write access for group
		if (permissionChange(770) != 0) {
             	   // log error
             	   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_ERR, "Failed 770 permission change for uploads and dashboard");
             	   closelog();
             	} else {
             	   // log success permission changed
             	   openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
             	   syslog(LOG_INFO, "Successful 770 permission change for uploads and dashboard");
             	   closelog();
             	}
             	
	     }
          }
          
       }
    }
 
    return 0;
}
