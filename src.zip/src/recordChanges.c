#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int recordChanges() {
   int status;
   pid_t childpid = fork();
   
   if (childpid > 0) {
     waitpid(childpid, &status, 0);
     //exit(EXIT_SUCCESS);
   } else if (childpid == 0) {
     // child process starts record changes script
     status = execl("/home/aaron/Documents/Assignment/src/scripts/recordChanges.sh", "recordChanges.sh", (char *)0);
     exit(EXIT_FAILURE);
   }
   
   return status;
}
