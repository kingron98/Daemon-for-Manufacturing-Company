#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

int backupDashboard() {
   pid_t childpid = fork();
   int status;
   
   if (childpid > 0) {
     waitpid(childpid, &status, 0);
     //exit(EXIT_SUCCESS);
   } else if (childpid == 0) {
     // child process starts backup script
     execl("/home/aaron/Documents/Assignment/src/scripts/backup.sh", "backup.sh", (char *)0);
     exit(EXIT_FAILURE);
   }
   
   return status;
}
