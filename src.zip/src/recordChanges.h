#ifndef RECORDCHANGES_H_
#define RECORDCHANGES_H_

int recordChanges();

#endif 
