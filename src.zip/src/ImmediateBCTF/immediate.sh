#!/bin/bash
#Purpose = Immediate backup and transfer
cd ..
PID=$(cat pid.txt)
kill -2 $PID

