#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int permissionChange(int num) {
   FILE *f = fopen("/home/aaron/Documents/Assignment/src/scripts/permission.sh", "w");
   int status;
   
   if (f == NULL) {
      // log error
   } else { 
      // write
      fprintf(f, "#!/bin/bash\n");
      fprintf(f, "#Purpose = Change Permission\n");
      fprintf(f, "chmod %d /home/aaron/Documents/Assignment/uploads/\n", num);
      fprintf(f, "chmod %d /home/aaron/Documents/Assignment/dashboard/\n", num);
      fclose(f);
      
      pid_t childpid = fork();
      if (childpid > 0) {
         waitpid(childpid, &status, 0);
         //exit(EXIT_SUCCESS);
      } else if (childpid == 0) {
         // child process starts permission script
         execl("/home/aaron/Documents/Assignment/src/scripts/permission.sh", "permission.sh", (char *)0);
         exit(EXIT_FAILURE);
      }
   }
   
   return status;
}
