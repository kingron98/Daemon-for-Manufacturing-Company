#!/bin/bash
#Purpose = Change Permission
chmod 770 /home/aaron/Documents/Assignment/uploads/
chmod 770 /home/aaron/Documents/Assignment/dashboard/
