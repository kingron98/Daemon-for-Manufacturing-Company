#!/bin/bash
#Purpose = Daemon controls
sudo systemctl $1 manuDaemon.service
