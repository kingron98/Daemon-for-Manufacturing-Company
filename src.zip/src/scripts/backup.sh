#!/bin/bash
#Purpose = Backup of Dashboard Content
DATE=$(date +"%d-%b-%Y")
cd /home/aaron/Documents/Assignment
tar -zcvf DASHBOARD-BACKUP-$DATE.tgz dashboard
mv *.tgz /home/aaron/Documents/Assignment/backup/
