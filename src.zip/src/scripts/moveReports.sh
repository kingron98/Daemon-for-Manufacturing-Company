#!/bin/bash
#Purpose = Move Reports from uploads to dashboard
mv /home/aaron/Documents/Assignment/uploads/* /home/aaron/Documents/Assignment/dashboard/
