#!/bin/bash
#Purpose = Record changes made to upload directory
sudo ausearch -f /home/aaron/Documents/Assignment/uploads/ | sudo aureport -f -i > /home/aaron/Documents/Assignment/report/changes-report.txt
