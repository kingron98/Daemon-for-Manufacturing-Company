#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int moveReports() {
   int status;
   pid_t childpid = fork();
   
   if (childpid > 0) {
      waitpid(childpid, &status, 0);
      //exit(EXIT_SUCCESS);
   } else if (childpid == 0) {
      // child process starts move reports script
      execl("/home/aaron/Documents/Assignment/src/scripts/moveReports.sh", "moveReports.sh", (char *)0);
      exit(EXIT_FAILURE);
   }
   
   return status;
}
