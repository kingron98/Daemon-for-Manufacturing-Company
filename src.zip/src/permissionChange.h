#ifndef PERMISSIONCHANGE_H_
#define PERMISSIONCHANGE_H_

int permissionChange(int num);

#endif 
