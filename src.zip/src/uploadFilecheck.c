#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>

void uploadFilecheck() {
   const char *path = "/home/aaron/Documents/Assignment/uploads/";
   const char *fname[4];
   
   // all required files to upload
   fname[0] = "warehouse.xml";
   fname[1] = "manufacturing.xml";
   fname[2] = "sales.xml";
   fname[3] = "distribution.xml";
   
   // use a for loop to loop through the required files
   for (int i = 0; i < 4; ++i) {
      char str[100] = "";
      strcat(str, path);
      strcat(str,fname[i]);
      // access the specified file pathname
      if (access(str, F_OK) == 0) {
         // all files exists
         openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
	 char *msg;
         
         // let function allocate memory
         asprintf(&msg, "%s uploaded on time", fname[i]);
         syslog(LOG_INFO, msg);
         
         // release the memory allocated from asprintf
         free(msg);
	 closelog();
      } else { // certain file does not exist
         // log the missing files
         openlog("Manufacturing logger", LOG_PID|LOG_CONS, LOG_DAEMON);
         char *msg;
         
         // let function allocate memory
         asprintf(&msg, "%s was not uploaded", fname[i]);
         syslog(LOG_INFO, msg);
         
         // release the memory allocated from asprintf
         free(msg);
         closelog();
      }
   }
}
